ite <- 50 # number of draws
n <- 800

# flag all abnormal phi values (|phi| >= 1)
ab_list <- matrix(rep(0,n*ite),nrow=n,ncol=ite)
for (j in seq(ite)){
  
  filename <- paste0('step1_imp',j,'.csv')
  step1result <- read.csv(filename, sep = '', header = F)
  colnames(step1result) <- c('Dep','NA','NA_lag1','AR1','logresvar','IM','Subject','TrueTime','Time')
  res_indiv <- step1result[step1result$Time == 1, ]
  
  abnormal <- rep(0, n)
  abnormal[which(abs(res_indiv[,'AR1']) >= 1)] <- 1
  ab_list[,j] <- abnormal
  
}

ab_list <- as.data.frame(ab_list)
ab_list[,'abnormal'] <- rowSums(ab_list)

# remove |phi|=1 values and calculate ISDest
for (l in seq(ite)){
  
  filename <- paste0('step1_imp',l,'.csv')
  step1result <- read.csv(filename, sep = '', header = F)
  colnames(step1result) <- c('Dep','NA','NA_lag1','AR1','logresvar','IM','Subject','TrueTime','Time')
  
  # get individual-level data
  res_indiv <- step1result[step1result$Time == 1, ]
  
  # remove individuals with out-of-range AR(1) draws from all datasets
  res_indiv <- res_indiv[which(ab_list$abnormal == 0),]
  
  # compute IVAR estimates
  res_indiv$IVARest <- exp(res_indiv$logresvar)/(1-res_indiv$AR1^2)
  
  # save data for Step 1
  ## Note: the original imputed datasets will be replaced to save space
  ## specify a different filename if one wants to save the imputed datasets
  write.table(res_indiv, filename, sep = ',', col.names = F, row.names = F)
  
}


