
library(data.table)

n <- 800
t <- 56

# import data
data <- read.csv('exampledata.csv', header = F)
colnames(data) <- c('N', 'T', 'NA','Dep')

# get individual-level data
data_indiv <- as.data.frame(matrix(rep(0,4*n), nrow = n, ncol = 4))
colnames(data_indiv) <- c('Dep', 'oIM', 'oAR1', 'oISD')
data_indiv[,'Dep'] <- data[data$T == 1, 'Dep']

for (i in 0:(n-1)){
  sample <- data[(t*i+1):(t*i+t), 'NA']
  
  # observed intraindividual mean (OIM)
  data_indiv[i+1, 'oIM'] <- mean(sample)
  
  #  AR(1) coefficient estimates
  m <- mean(sample)
  denom <- sum((sample-m)^2)
  num <- 0
  for (j in 1:(t-1)){
    num <- num + (sample[j+1]-m)*(sample[j]-m)
  }
  data_indiv[i+1, 'oAR1'] <- num/denom
  
  # observed within-person standard deviation (OISD)
  data_indiv[i+1, 'oISD'] <- sd(sample)
}

model <- lm(Dep ~ oIM + oAR1 + oISD, data = data_indiv)
summary(model)
confint(model)



