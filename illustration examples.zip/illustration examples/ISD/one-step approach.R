library(data.table)
library(R2jags)

n <- 800 # number of subjects
t <- 56 # number of time points

# import data
data <- read.csv('exampledata.csv', header=F)
colnames(data) <- c('n', 't', 'NA', 'dep')

## ------------------- initialization ----------------------
stbpre1 = matrix(c(.6, 0, 0,
                   0,.04,0,
                   0,0, 1.9),3,3,byrow=TRUE)
stbpre2 = matrix(c(.5, 0, 0,
                   0,.08,0,
                   0,0, 2),3,3,byrow=TRUE)

inits1 <- list( bmu=c(1,0.3,-2),bpre=stbpre1, beta0=0, beta1=20, beta2=1, beta3=0, pre.b=1) ###for chain1
inits2 <- list(bmu=c(1.5,0.5,-2.5), bpre=stbpre2, beta0=.1, beta1=10, beta2=0, beta3=1, pre.b=.9) ###for chain 2

inits <- list(inits1, inits2) ## initial values
params <- c("beta1", "beta2", "beta3")

## ------------------- specify data ----------------------
constraint <- rep(1,n) # a trick to make sure AR(1) are sampled within (-1, 1)
dep <- data[data$t == 1, 'dep']
dat <- list("n"=n, "t"=t, "y"=data[ ,'NA'], 'dep'=dep, 'cons1'=constraint)

## ------------------- run model ----------------------
set.seed(123)
out <- jags(data=dat, 
            inits=inits,
            parameters.to.save=c("beta1","beta2","beta3"),
            model.file='onestep_SD.txt',
            n.chains=2,
            n.iter = 10000,
            n.thin=10,
            n.burnin=5000,
            quiet=T)

result <- as.data.frame(out$BUGSoutput$summary)
result


