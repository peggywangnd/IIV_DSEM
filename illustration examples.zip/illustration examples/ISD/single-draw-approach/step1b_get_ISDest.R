
n <- 800

# import step-1 output
step1results <- read.csv('result.csv', sep = '', header = F)
colnames(step1results) <- c('Dep','NA','NA_lag1','AR1_mean','AR1_median','AR1_sd','AR1_low','AR1_up',
                  'logresvar_mean','logresvar_median','logresvar_sd','logresvar_low','logresvar_up',
                  'IM_mean','IM_median','IM_sd','IM_low','IM_up','Subject','TrueTime','Time')

# get individual-level data
res_indiv <- step1results[step1results$Time == 1, ]

# remove AR(1) medians that are outside (-1, 1)
res_indiv <- res_indiv[which(abs(res_indiv[,'AR1_median']) < 1),]

# get ISD estimate
res_indiv$ISDest <- sqrt(exp(res_indiv$logresvar_median)/(1-res_indiv$AR1_median^2))

# save data for Step 2
res_final <- res_indiv[,c('Dep','IM_median','AR1_median','ISDest','Subject')]
write.table(res_final, 'step2data.csv', sep = ',', col.names = F, row.names = F)


